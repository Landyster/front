export default class ChargeReport{

}